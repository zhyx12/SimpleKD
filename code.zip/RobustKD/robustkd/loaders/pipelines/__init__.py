#
# ----------------------------------------------
from mmcls.datasets.pipelines import Compose
from .pipelines import Apply, ColorJitter
from .builder import CLS_PIPELINES


if __name__ == "__main__":
    pass
