#
# ----------------------------------------------
from .trainer_clip_distill import TrainerCLIPDistill, ValidatorCLIPDistill
