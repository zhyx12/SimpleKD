import os
import shutil


def replace_dataset_args(args: dict):
    logdir = args.logdir

